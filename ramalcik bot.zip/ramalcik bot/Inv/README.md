# FC-INVITE-BOT-V13

# NOT
* Bot hem slash komut hemde normal komut ile çalışıyor.
* İsterseniz `.` prefixi ile kullanın isterseniz `/` prefixi ile slash komut komut kullanın.

# KURULUM
* [Node.JS](https://nodejs.org/en/) Cihazınınızda Node kurulu olduğundan emin olun!
* Yeşil Code butonuna basın ve Downland zip seçeneğine tıklayın indirme işlemini bekleyin.
* İndirme işlemi tamamlandığında zipin üstüne gelerek buraya çıkartı işaretleyin.
* Klasörü çıkardıkdan sonra `config.js` adlı dosyayı doldurmanız gerekmekte doğru bir şekilde doldurduğunuzdan emin olun.
* `config.js` dosyasında bulunan `mongoURL` kısmına mongo linkinizi girin, Mongo linki almayı bilmiyorsanız [Tıklayın](https://www.youtube.com/watch?v=s_-gJn9GDus)
* Terminali açıp `npm install` yazıp gerekli modüllerin inmesini bekleyin indikten sonra `npm test` yazarak botu başlatın!
* İNTENTLERİ AÇMAYI UNUTMAYIN !!!!!!! 

# KULLANIM
* Bottaki gerekli kurulumları yaptıktan sonra `.yardım` komutu ile önünüze çıkan yardım menüsünden komutlara ulaşabilirsiniz.

# Sıkça Sorulan Sorular (SSS) / Alınan Hatalar
* `Error [TOKEN_INVALID]: An invalid token was provided.` böyle bir hata ile karşılaşırsanız tokeniniz yanlıştır config.js/bot.botToken kısmından botunuzun tokenini kontrol edin!

# İLETİŞİM
* Botla ilgili herhangi bir hata veya soru için [Ferzah](https://discord.com/users/564900904713846785) veya [Cross](https://discord.com/users/641256228101554188)'a ulaşabilirsiniz.
* Yardım almak için [Wext](https://www.discord.gg/1972) Sunucusunu ziyaret edebilirsiniz.
